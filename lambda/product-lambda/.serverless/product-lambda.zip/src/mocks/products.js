export const productsMock = [
  {
    id: '1',
    name: 'name 1',
    description: 'description 1',
    price: 1
  }
]